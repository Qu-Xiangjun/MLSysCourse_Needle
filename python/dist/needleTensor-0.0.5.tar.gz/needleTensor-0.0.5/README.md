NeedleTensor from CMU 10-714 homework.

